<?php
$hours = array(
			"10:30",
			"11:30",
			"12:30",
			"13:30",
			"14:30"
	);
echo json_encode($hours);
?>