<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$app = appBook();

?>
<div class="row-fluid">
	<div class="pull-left">
		<h4><a href="<?php echo esc_url( add_query_arg( 'booking', '0', site_url( '/rendez-vous/' ) ) ); ?>" class="btn btn-success" style="text-decoration:none;"><?php _e('Ajouter un rendez-vous', $app->slug); ?></a></h4>
	</div>
</div>
<div class="clearfix"></div>
<div id="booking"></div>
<script type="text/javascript">
<?php 
if(!empty($app->app->datas->hour_zone)){ ?>
	var bookingTimezone = '<?php echo $app->app->datas->hour_zone ?>';
<?php }
else{ ?>
	var bookingTimezone = false;
<?php
}
?>
var closingEventsSingle = <?php echo json_encode($app->app->closing->getClosingEventsSingle()); ?>;
var closingEventsFrequenty = <?php echo json_encode($app->app->closing->getClosingEventsFrequenty()); ?>;
var isSingle = false;
</script>