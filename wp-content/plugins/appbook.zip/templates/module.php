<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$app = appBook();
$module = $app->app->module->datas;
if($module === null)
{
	$form_action = 'module_new';
	$display = false;
}
else{
	$display = true;
}
?>
<div class="page-header row">
	<h2>
		<?php if ($display === false)
			echo __('Générer le module', $app->slug);
		else
			echo __('Paramètre du module', $app->slug);
		?>
	</h2>
</div>
<?php if($module === null)
{ ?>
<div class="alert alert-info pull-right col-xs-12 col-sm-4">
<p>Cette partie est essentiel. Elle crée votre application à partir des données et informations que vous avez fournies.</p>
</div>
<form id="<?php echo $app->slug; ?>_app<?php echo '_'.$form_action?>"  class="<?php echo $app->slug; ?>_form form-inline col-xs-12 col-sm-8 pull-left" method="POST" action="">
	<div class="form-group">
	    <label for="folder"><?php _e('Nom de votre dossier', $app->slug) ?></label>
	    <input type="text" class="form-control" id="folder" name="<?php echo $form_action ?>[folder]">
  	</div>
  	<button type="submit" class="btn btn-default"><?php _e('Générer', $app->slug); ?></button>
  	<?php wp_nonce_field( $form_action, $app->slug.'_'.$form_action ) ?>
</form>
<?php }else{ ?>
<p class="alert alert-info "><?php _e('Votre est module prêt. Merci de votre confiance.', $app->slug) ?></p>
<?php } ?>