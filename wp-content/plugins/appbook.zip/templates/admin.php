<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $wpdb;
$app = appBook();
if(isset($_GET['rdv_action']) && $_GET['rdv_action'] == 'regenerate')
{
	// var_dump(dirname(__FILE__).'../includes/class-module.php');exit;
	// require_once( dirname(__FILE__).'/../includes/class-module.php' );
	// var_dump('regeneration');exit;
	// $res = AppModule::regenerate();
	// var_dump($res);exit;
	// var_dump($res);exit;
	// if($res === false)
	// 	$msg = '<span>'.__('Une erreur est survenue pendant la régénération.', $app->slug).'</span>';
	// else
	// 	$msg = '<span>'.__('La régénération a été effectuée avec succès.', $app->slug).'</span>';
}
else
	$msg = '';
//fin regeneration
$pagenum = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
$limit = 10;
$offset = ( $pagenum - 1 ) * $limit;
$total = $wpdb->get_var( "SELECT COUNT(`app_id`) FROM `".$wpdb->prefix.appBook()->slug."_app`" );
$num_of_pages = ceil( $total / $limit );
$all = $wpdb->get_results( 
	"
	SELECT *
	FROM `{$wpdb->prefix}appbook_app`
	ORDER BY `app_id` DESC
	LIMIT {$offset}, {$limit}
	", OBJECT
);
?>
<div id="app-loading" style="display: none;"><div class="app-loading-anim"></div></div>
<div class="wrap">
	<?php echo $msg ?>
 	<h1 id="rdv-title">
 		<?php _e('Applications RDV', $app-slug); ?>&nbsp;&nbsp;&nbsp;
 		<button id="regenerate-module" class="page-title-action"><?php _e('Régénérer les modules', $app->slug) ?></button>
 	</h1>
 	<ul class="subsubsub">
		<li class="all">Tous <span class="count">(<?php echo $total ?>)</span></li>
	</ul>
	<table class="wp-list-table widefat fixed striped">
		<thead>
			<tr>
				<th scope="col" class="manage-column checking"><input type="checkbox" class="module_all" name="module_all"></th>
				<th scope="col" class="manage-column app-name"><?php _e('Société', appBook()->slug) ?></th>
				<th scope="col" class="manage-column app-link"><?php _e('Lien du module', appBook()->slug) ?></th>
				<th scope="col" class="manage-column app-comments"><?php _e('Commentaires', appBook()->slug) ?></th>
				<th scope="col" class="manage-column app-actions"><?php _e('Supprimer', appBook()->slug) ?></th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<th scope="col" class="manage-column checking"><input type="checkbox" class="module_all" name="module_all"></th>
				<th scope="col" class="manage-column app-name"><?php _e('Société', appBook()->slug) ?></th>
				<th scope="col" class="manage-column app-link"><?php _e('Lien du module', appBook()->slug) ?></th>
				<th scope="col" class="manage-column app-comments"><?php _e('Commentaires', appBook()->slug) ?></th>
				<th scope="col" class="manage-column app-actions"><?php _e('Supprimer', appBook()->slug) ?></th>
			</tr>
		</tfoot>
		<tbody>
		<?php foreach ($all as $key => $single) { ?>
			<?php
			$app_id = (int)$single->app_id;
			$query = "SELECT * FROM `{$wpdb->prefix}{$app->slug}_module` WHERE `app_id`={$app_id}";
			$module = $wpdb->get_row($query, OBJECT);  
			?>
			<tr id="<?php echo $single->app_id ?>">
				<td class="checking"><input type="checkbox" class="module-rdv" name="module[]" value="<?php echo $single->app_id ?>"></td>
				<td class="app-name"><?php echo $single->app_name; ?></td>
				<?php 
				if($module === null)
					$folder_text = __('Pas encore généré', appBook()->slug);
				else
					$folder_text = site_url('/').$module->folder.'/';
				?>
				<td class="app-link"><?php echo $folder_text; ?></td>
				<td class="app-comments"><textarea name="comment" style="width: 100%"><?php echo $module->comments ?></textarea><br /><button data-id="<?php echo $single->app_id ?>" data-module="<?php echo $module->module_id ?>" type="button" name="save_comments" class="save-comments button button-primary"><?php echo _('Enregistrer') ?></button></td>
				<td class="app-actions"><button data-id="<?php echo $single->app_id ?>" type="button" class="delete-app button button-secondary"><?php echo _('Supprimer') ?></button></td>
			</tr>
		<?php 
		}
		?>
		</tbody>
	</table>
</div>
<script type="text/javascript">
	jQuery('.module_all').change(function(){
		jQuery('.module-rdv').prop("checked", this.checked);
		jQuery('.module_all').prop("checked", this.checked);
	});
	jQuery('.module-rdv').change(function(){
		jQuery('.module-rdv').each(function(i){
			if (this.checked == false)
			{
				jQuery('.module_all').prop("checked", false);
				return;
			}
		});
	});
	jQuery('#regenerate-module').click(function(){
		var ajaxurl = '<?php echo admin_url( 'admin-ajax.php' ) ?>';
		if ( jQuery('.module-rdv').is(":checked") === false )
		{
			alert("<?php echo __('Veuillez cocher une ou plusieurs société(s).') ?>");
			return false;
		}
		if (jQuery('.module_all').is(":checked") == true)
		{
			var confirmRegenerateAll = confirm('Voulez-vous régénérer tous les modules?');
			if (confirmRegenerateAll === true) {
				jQuery('#app-loading').show();
				jQuery.post(
				    ajaxurl, 
				    {
				        'action': '<?php echo appBook()->slug.'_regenerate_module' ?>',
				        'data': 'all'
				    }, 
				    function(response){
				    	jQuery('#app-loading').hide();
				    	if (response == "1")
				        	jQuery('#rdv-title').before('<div>La régénération de tous les modules a été effectuée.</div>');
				        else
				        	alert('Erreur');
				    }
				);
			}
		}else {
			var confirmRegenerate = confirm('Voulez-vous vraiment régénérer?');
			if (confirmRegenerate === true)
			{
				jQuery('#app-loading').show();
				var inputs = jQuery('.module-rdv');
				var ids = '';
				inputs.each(function(i){
					ids += (i!=0?',':'')+ijQuery(this).val();
				});
				jQuery.post(
				    ajaxurl, 
				    {
				        'action': '<?php echo appBook()->slug.'_regenerate_module' ?>',
				        'data': ids
				    }, 
				    function(response){
				    	jQuery('#app-loading').hide();
				    	if (response == "1")
				        	jQuery('#rdv-title').before('<div>La régénération a été effectuée.</div>');
				        else
				        	alert('Erreur');
				    }
				);
			}else {
				return false;
			}
		}
	});

	// save comment
	jQuery('.save-comments').click(function(){
		var confirmation = confirm('<?php _e('Voulez-vous enregistrer le commentaire?', $app->slug); ?>');
		if (confirmation === true)
		{
			saveComment(this);
		}
	});
	function saveComment(app)
	{
		jQuery('#app-loading').show();
		var ajaxurl = '<?php echo admin_url( 'admin-ajax.php' ) ?>';
		var posting = jQuery.post(
			ajaxurl,
			{
				'action': '<?php echo appBook()->slug.'_update_comment' ?>',
				'app_id': jQuery(app).data('id'),
				'module_id': jQuery(app).data('module'),
				'comment': jQuery('tr#'+jQuery(app).data('id')+' textarea[name="comment"]').val(),
			}
		);
		posting.done(function(response){
			jQuery('#app-loading').hide();
			if(response == '0'){
				alert("<?php echo __("Le commentaire n'a pas été enregistré.", $app-slug); ?>");
			}
			if(response == '1'){
				alert('<?php echo __('Le commentaire a été enregistré avec succès.', $app-slug); ?>');
			}
		});
	}

	// delete
	jQuery('.delete-app').click(function(){
		var confirmDelete = confirm('<?php _e('Voulez-vous vraiment supprimer cette société et toutes ses données?', $app->slug) ?>');
		if(confirmDelete === true)
		{
			deleteApp(this);
		}
	});
	function deleteApp(app){
		jQuery('#app-loading').show();
		var ajaxurl = '<?php echo admin_url( 'admin-ajax.php' ) ?>';
		var posting = jQuery.post(
			ajaxurl,
			{
				'action': '<?php echo appBook()->slug.'_delete_app' ?>',
				'app_id': jQuery(app).data('id'),
			}
		);
		posting.done(function(response){
			jQuery('#app-loading').hide();
			if(response == '1'){
				alert('<?php echo __('La société a été supprimée avec succès.', $app-slug); ?>');
				jQuery('tr#'+jQuery(app).data('id')).remove();
			}
			else if(response == '0'){
				alert("<?php echo __("La société n'a pas été supprimée.", $app-slug); ?>");
			}
			else{
				alert(response);
			}
		});
	}
</script>