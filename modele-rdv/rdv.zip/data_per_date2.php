<?php
$hours = array(
			"12:30",
			"13:30",
			"14:30",
			"15:30",
			"16:30"
	);
echo json_encode($hours);
?>