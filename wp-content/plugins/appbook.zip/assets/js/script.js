if(rdv.logged == '1')
{
	jQuery('#menu-item-31').remove();
}
if(rdv.logged == '0')
{
	jQuery('#menu-item-55').remove();
	jQuery('#menu-item-65').remove();
}