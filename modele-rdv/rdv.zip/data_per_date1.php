<?php
$hours = array(
			"07:30",
			"08:30",
			
	);
echo json_encode($hours);
?>